# MediAI - Free Deployment Guide

This guide deploys MediAI **for free** using:
- **Render.com** for the Express API server (free tier)
- **Neon.tech** or **Supabase** for the PostgreSQL database (free tier)
- **Vercel** for the React frontend (free tier)

You will get a public website like `https://medai.vercel.app` that anyone can visit from any device.

---

## Step 1 — Create a free PostgreSQL database

### Option A: Neon (recommended, simplest)

1. Go to https://neon.tech and sign up with GitHub/Google.
2. Create a project (region closest to your users).
3. Copy the **Connection String** that starts with `postgresql://...`. This is your `DATABASE_URL`.

### Option B: Supabase

1. Go to https://supabase.com and create a new project (free tier).
2. From **Project Settings → Database**, copy the **Connection String (pooler)** under "Connection pooling".
3. Replace `[YOUR-PASSWORD]` with the password you set. This is your `DATABASE_URL`.

After getting your `DATABASE_URL`, locally run:

```bash
DATABASE_URL="<your-connection-string>" pnpm --filter @workspace/db run push-force
```

This creates all the tables (blog_posts, community_posts, vitals, etc.) on your new database.

---

## Step 2 — Get your OpenAI key

1. Go to https://platform.openai.com/api-keys
2. Create a new secret key — copy it. This is your `AI_INTEGRATIONS_OPENAI_API_KEY`.
3. Your `AI_INTEGRATIONS_OPENAI_BASE_URL` is `https://api.openai.com/v1`.

> **Note:** The model name in `artifacts/api-server/src/lib/ai.ts` is `gpt-5.4`. Replace with `gpt-4o-mini` (or another available model) when deploying outside Replit's AI integration:
>
> ```ts
> export const MODEL = "gpt-4o-mini";
> ```

---

## Step 3 — Push your code to GitHub

```bash
git init
git add .
git commit -m "Initial MediAI deployment"
gh repo create medai --public --source=. --push
# OR create the repo on github.com manually then:
# git remote add origin https://github.com/<you>/medai.git
# git push -u origin main
```

---

## Step 4 — Deploy the API on Render (free)

1. Go to https://render.com and sign up.
2. Click **New → Blueprint**.
3. Connect your GitHub account, select the **medai** repo.
4. Render reads the included `render.yaml` automatically and creates the web service.
5. In the **Environment** tab of the new service, add the secrets:
   - `DATABASE_URL` — from Step 1
   - `AI_INTEGRATIONS_OPENAI_API_KEY` — from Step 2
   - `AI_INTEGRATIONS_OPENAI_BASE_URL` — `https://api.openai.com/v1`
6. Click **Deploy**.
7. After 5–10 minutes, your API will be live at:
   `https://medai-api.onrender.com`

> Render's free tier sleeps after 15 min of inactivity. First request after sleep takes ~30 seconds.

---

## Step 5 — Deploy the frontend on Vercel (free)

1. Go to https://vercel.com and sign up with GitHub.
2. Click **Add New → Project**, select the **medai** repo.
3. Vercel reads the included `vercel.json`.
4. **Important:** open `vercel.json` and replace the two occurrences of
   `https://YOUR-RENDER-API.onrender.com`
   with your real Render URL from Step 4 (e.g. `https://medai-api.onrender.com`).
   Commit and push the change.
5. Click **Deploy**.
6. After 2–4 minutes you get a public URL like `https://medai.vercel.app`.

---

## Step 6 — Visit your live website

Open your Vercel URL on any device — phone, tablet, computer. You should see your full MediAI site running on the public internet, with:

- 6 languages (English, Arabic, French, Spanish, Chinese, Hindi)
- Symptom checker, drug interactions, AI consultations
- Health blog (auto-generated daily by AI)
- Community Q&A
- Installable as a mobile app (PWA)
- Privacy + Terms pages
- Cookie consent

---

## Optional: Custom domain

On Vercel → Project → Settings → Domains, you can add your own domain (e.g. `medai.com`) for free. Vercel provides automatic HTTPS.

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Frontend loads but API returns 404 | The `/api/*` rewrite in `vercel.json` is not pointing to your real Render URL. |
| Render build fails on `pnpm install` | Set Node version: in Render service → Settings → Node version → `20`. |
| AI features error 500 | Check your OpenAI key has credit, and that `MODEL` in `ai.ts` is a valid model. |
| Database tables missing | Re-run Step 1's `push-force` command with your `DATABASE_URL`. |

---

## Free tier limits to know

| Service | Limit |
|---------|-------|
| Render web service | 750 hours/month, sleeps after 15 min idle |
| Neon Postgres | 0.5 GB storage, 1 project |
| Supabase Postgres | 500 MB storage, paused after 1 week of inactivity |
| Vercel | 100 GB bandwidth/month, unlimited static deploys |
| OpenAI | Pay as you go — set a usage cap in your OpenAI dashboard |

That's it. Your full MediAI is live on the internet, completely free.

---

**Engineered by Eng. Abdulrazzaq / المهندس عبدالرزاق**
