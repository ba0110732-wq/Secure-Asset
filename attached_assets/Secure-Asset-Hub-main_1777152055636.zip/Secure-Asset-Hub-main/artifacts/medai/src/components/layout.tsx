import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useI18n } from "@/lib/i18n";
import { useTheme } from "next-themes";
import { 
  Activity, 
  Stethoscope, 
  Pill, 
  MessageSquare, 
  HeartPulse, 
  User, 
  CreditCard, 
  Menu,
  Moon,
  Sun,
  Languages,
  Newspaper,
  Users,
  UserCircle,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LANGUAGES } from "@/lib/i18n";

export function Layout({ children }: { children: React.ReactNode }) {
  const { t, language, setLanguage } = useI18n();
  const { theme, setTheme } = useTheme();
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const navItems = [
    { href: "/", label: t("dashboard"), icon: Activity },
    { href: "/symptoms", label: t("symptomChecker"), icon: Stethoscope },
    { href: "/drugs", label: t("drugInteractions"), icon: Pill },
    { href: "/consultations", label: t("consultations"), icon: MessageSquare },
    { href: "/vitals", label: t("vitalSigns"), icon: HeartPulse },
    { href: "/profile", label: t("healthProfile"), icon: User },
    { href: "/blog", label: t("blog"), icon: Newspaper },
    { href: "/community", label: t("community"), icon: Users },
    { href: "/account", label: t("account"), icon: UserCircle },
    { href: "/pricing", label: t("pricing"), icon: CreditCard },
  ];

  const SidebarContent = () => (
    <div className="flex h-full flex-col">
      <div className="flex h-16 items-center justify-between px-6 border-b">
        <Link href="/" className="flex items-center gap-2 font-semibold text-lg">
          <HeartPulse className="h-6 w-6 text-primary" />
          <div className="flex flex-col">
            <span className="leading-tight">{t("brandTitle")}</span>
            <span className="text-[10px] text-muted-foreground leading-tight uppercase tracking-wider">{t("brandSubtitle")}</span>
          </div>
        </Link>
      </div>
      
      <div className="flex-1 overflow-y-auto py-4">
        <nav className="grid gap-1 px-3">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all hover:text-primary ${
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:bg-muted"
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </div>
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="p-4 border-t text-xs text-center text-muted-foreground bg-muted/30">
        {t("credit")}
      </div>
    </div>
  );

  return (
    <div className="flex min-h-[100dvh] w-full bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden border-r bg-card w-64 md:block flex-shrink-0">
        <SidebarContent />
      </aside>

      <div className="flex flex-1 flex-col overflow-hidden">
        <header className="flex h-16 items-center justify-between border-b bg-card px-4 md:px-6 shrink-0 z-10">
          <div className="flex items-center gap-4 md:hidden">
            <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="-ml-2">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Toggle navigation menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side={language === "ar" ? "right" : "left"} className="w-72 p-0">
                <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
                <SheetDescription className="sr-only">Access app pages</SheetDescription>
                <SidebarContent />
              </SheetContent>
            </Sheet>
            <Link href="/" className="flex items-center gap-2 font-semibold">
              <HeartPulse className="h-5 w-5 text-primary" />
              <span>{t("brandTitle")}</span>
            </Link>
          </div>

          <div className="hidden md:block">
            {/* Title can go here, or left empty */}
          </div>

          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" title="Language" data-testid="button-language">
                  <Languages className="h-5 w-5" />
                  <span className="sr-only">Language</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {LANGUAGES.map((l) => (
                  <DropdownMenuItem
                    key={l.code}
                    onClick={() => setLanguage(l.code)}
                    className={language === l.code ? "bg-accent" : ""}
                    data-testid={`menu-lang-${l.code}`}
                  >
                    <span className="me-2 inline-block w-8 text-xs uppercase text-muted-foreground">
                      {l.code}
                    </span>
                    {l.native}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            >
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto">
          <div className="container max-w-6xl mx-auto p-4 md:p-6 lg:p-8">
            {children}
          </div>
          
          <footer className="mt-8 border-t py-6 text-center text-sm text-muted-foreground">
            <div className="container max-w-4xl mx-auto px-4">
              <p className="mb-2">{t("disclaimer")}</p>
              <p className="font-medium">{t("credit")}</p>
            </div>
          </footer>
        </main>
      </div>
    </div>
  );
}
