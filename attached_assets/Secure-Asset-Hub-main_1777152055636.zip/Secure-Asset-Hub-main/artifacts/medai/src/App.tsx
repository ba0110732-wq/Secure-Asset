import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { I18nProvider } from "@/lib/i18n";
import { ThemeProvider } from "next-themes";
import { Layout } from "@/components/layout";
import { CookieConsent } from "@/components/cookie-consent";
import { OfflineIndicator } from "@/components/offline-indicator";

// Pages
import Dashboard from "@/pages/dashboard";
import Symptoms from "@/pages/symptoms";
import Drugs from "@/pages/drugs";
import Consultations from "@/pages/consultations";
import Consultation from "@/pages/consultation";
import Vitals from "@/pages/vitals";
import Profile from "@/pages/profile";
import Pricing from "@/pages/pricing";
import Account from "@/pages/account";
import Blog from "@/pages/blog";
import BlogPost from "@/pages/blog-post";
import Community from "@/pages/community";
import CommunityPostPage from "@/pages/community-post";
import Privacy from "@/pages/privacy";
import Terms from "@/pages/terms";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false, refetchOnWindowFocus: false },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/symptoms" component={Symptoms} />
        <Route path="/drugs" component={Drugs} />
        <Route path="/consultations" component={Consultations} />
        <Route path="/consultations/:id" component={Consultation} />
        <Route path="/vitals" component={Vitals} />
        <Route path="/profile" component={Profile} />
        <Route path="/pricing" component={Pricing} />
        <Route path="/account" component={Account} />
        <Route path="/blog" component={Blog} />
        <Route path="/blog/:slug" component={BlogPost} />
        <Route path="/community" component={Community} />
        <Route path="/community/:id" component={CommunityPostPage} />
        <Route path="/privacy" component={Privacy} />
        <Route path="/terms" component={Terms} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <I18nProvider>
          <TooltipProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <Router />
            </WouterRouter>
            <OfflineIndicator />
            <CookieConsent />
            <Toaster position="top-center" />
          </TooltipProvider>
        </I18nProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
