import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export type Language = "en" | "ar" | "fr" | "es" | "zh" | "hi";

export const LANGUAGES: { code: Language; label: string; native: string; dir: "ltr" | "rtl" }[] = [
  { code: "en", label: "English", native: "English", dir: "ltr" },
  { code: "ar", label: "Arabic", native: "العربية", dir: "rtl" },
  { code: "fr", label: "French", native: "Français", dir: "ltr" },
  { code: "es", label: "Spanish", native: "Español", dir: "ltr" },
  { code: "zh", label: "Chinese", native: "中文", dir: "ltr" },
  { code: "hi", label: "Hindi", native: "हिन्दी", dir: "ltr" },
];

const en = {
  dashboard: "Dashboard",
  symptomChecker: "Symptom Checker",
  drugInteractions: "Drug Interactions",
  consultations: "AI Consultations",
  vitalSigns: "Vital Signs",
  healthProfile: "Health Profile",
  pricing: "Pricing",
  blog: "Health Blog",
  community: "Community",
  account: "My Account",
  privacy: "Privacy Policy",
  terms: "Terms of Service",

  brandTitle: "MediAI",
  brandSubtitle: "Health Intelligence",
  credit: "Engineered by Eng. Abdulrazzaq",
  disclaimer:
    "MediAI provides health information and AI-powered analysis for educational purposes only. Always consult qualified healthcare professionals for medical decisions.",

  consultationsCount: "Consultations",
  symptomChecksCount: "Symptom Checks",
  drugChecksCount: "Drug Interaction Checks",
  vitalRecordsCount: "Vital Records",
  lastVitalAt: "Last Vitals Recorded",
  never: "Never",
  quickActions: "Quick Actions",
  checkSymptoms: "Check Symptoms",
  checkDrugs: "Check Drug Interactions",
  startConsultation: "Start Consultation",
  recordVitals: "Record Vitals",
  recentActivity: "Recent Activity",
  healthTip: "Health Tip of the Day",

  describeSymptoms: "Describe your symptoms in detail...",
  submitSymptoms: "Analyze Symptoms",
  pastChecks: "Past Symptom Checks",
  severity: "Severity",
  analysis: "Analysis",
  recommendations: "Recommendations",
  noSymptomChecks: "No symptom checks yet.",

  drugName: "Drug Name",
  addDrug: "Add Another Drug",
  checkInteractions: "Check Interactions",
  pastDrugChecks: "Past Drug Checks",
  riskLevel: "Risk Level",
  interactionsLabel: "Interactions",
  noDrugChecks: "No drug interaction checks yet.",

  newConsultation: "New Consultation",
  pastConsultations: "Past Consultations",
  typeMessage: "Type your message...",
  send: "Send",
  noConsultations: "No consultations yet. Start one to get advice.",

  heartRate: "Heart Rate (bpm)",
  bloodPressure: "Blood Pressure (Sys/Dia)",
  temperature: "Temperature (°C)",
  oxygenSaturation: "SpO2 (%)",
  bloodSugar: "Blood Sugar (mg/dL)",
  weight: "Weight (kg)",
  notes: "Notes",
  saveVitals: "Save Vitals",
  pastVitals: "Past Vital Records",
  noVitals: "No vital signs recorded yet.",
  recentHeartRate: "Recent Heart Rate",

  fullName: "Full Name",
  age: "Age",
  gender: "Gender",
  height: "Height (cm)",
  bloodType: "Blood Type",
  allergies: "Allergies",
  chronicConditions: "Chronic Conditions",
  currentMedications: "Current Medications",
  saveProfile: "Save Profile",

  free: "Free",
  pro: "Pro",
  clinic: "Clinic",
  perMonth: "/month",

  loading: "Loading...",
  error: "An error occurred.",
  success: "Success",
  retry: "Retry",
  cancel: "Cancel",
  save: "Save",
  share: "Share this result",

  // Blog
  blogTitle: "Health Articles",
  blogSubtitle: "AI-curated daily insights",
  blogReadMore: "Read more",
  blogNoPosts: "No articles yet. Check back tomorrow.",
  blogPublished: "Published",

  // Community
  communityTitle: "Community Q&A",
  communitySubtitle: "Ask questions, help others",
  newPost: "New Post",
  postTitle: "Title",
  postBody: "Question or message",
  yourName: "Your name (optional)",
  publish: "Publish",
  replies: "Replies",
  reply: "Reply",
  writeReply: "Write a reply...",
  noPosts: "No discussions yet. Start the first one.",
  back: "Back",

  // Account
  accountTitle: "My Account",
  currentPlan: "Current Plan",
  usageStats: "Usage Statistics",
  upgrade: "Upgrade Plan",
  totalConsultations: "Total Consultations",
  totalSymptomChecks: "Total Symptom Checks",
  totalDrugChecks: "Total Drug Checks",
  totalVitalRecords: "Total Vital Records",
  memberSince: "Member since",

  // Cookie banner
  cookieMessage:
    "We use cookies to improve your experience and analyze site usage. By continuing, you agree to our cookie policy.",
  accept: "Accept",
  decline: "Decline",

  // Privacy / Terms
  privacyTitle: "Privacy Policy",
  termsTitle: "Terms of Service",
  lastUpdated: "Last updated",

  // Offline
  offlineMessage: "You are offline. Work will resume when you reconnect.",

  // Common
  tryAgain: "Try again",
  posted: "Posted",
};

type Dict = typeof en;

const ar: Dict = {
  dashboard: "لوحة القيادة",
  symptomChecker: "فحص الأعراض",
  drugInteractions: "تفاعلات الأدوية",
  consultations: "الاستشارات الذكية",
  vitalSigns: "العلامات الحيوية",
  healthProfile: "الملف الصحي",
  pricing: "الأسعار",
  blog: "المدونة الصحية",
  community: "المجتمع",
  account: "حسابي",
  privacy: "سياسة الخصوصية",
  terms: "شروط الخدمة",

  brandTitle: "MediAI",
  brandSubtitle: "الذكاء الصحي",
  credit: "صُمم بواسطة المهندس عبدالرزاق",
  disclaimer:
    "تقدم MediAI المعلومات الصحية والتحليلات المدعومة بالذكاء الاصطناعي للأغراض التعليمية فقط. استشر دائمًا أخصائيي الرعاية الصحية المؤهلين لاتخاذ القرارات الطبية.",

  consultationsCount: "الاستشارات",
  symptomChecksCount: "فحوصات الأعراض",
  drugChecksCount: "فحوصات تفاعلات الأدوية",
  vitalRecordsCount: "السجلات الحيوية",
  lastVitalAt: "آخر تسجيل للعلامات الحيوية",
  never: "أبداً",
  quickActions: "إجراءات سريعة",
  checkSymptoms: "فحص الأعراض",
  checkDrugs: "التحقق من تفاعلات الأدوية",
  startConsultation: "بدء استشارة",
  recordVitals: "تسجيل العلامات الحيوية",
  recentActivity: "النشاط الأخير",
  healthTip: "نصيحة صحية لليوم",

  describeSymptoms: "صف أعراضك بالتفصيل...",
  submitSymptoms: "تحليل الأعراض",
  pastChecks: "فحوصات الأعراض السابقة",
  severity: "الخطورة",
  analysis: "التحليل",
  recommendations: "التوصيات",
  noSymptomChecks: "لا توجد فحوصات أعراض بعد.",

  drugName: "اسم الدواء",
  addDrug: "إضافة دواء آخر",
  checkInteractions: "التحقق من التفاعلات",
  pastDrugChecks: "فحوصات الأدوية السابقة",
  riskLevel: "مستوى الخطر",
  interactionsLabel: "التفاعلات",
  noDrugChecks: "لا توجد فحوصات تفاعلات أدوية بعد.",

  newConsultation: "استشارة جديدة",
  pastConsultations: "الاستشارات السابقة",
  typeMessage: "اكتب رسالتك...",
  send: "إرسال",
  noConsultations: "لا توجد استشارات بعد. ابدأ واحدة للحصول على المشورة.",

  heartRate: "معدل ضربات القلب (bpm)",
  bloodPressure: "ضغط الدم (انقباضي/انبساطي)",
  temperature: "درجة الحرارة (°C)",
  oxygenSaturation: "نسبة الأكسجين (%)",
  bloodSugar: "سكر الدم (mg/dL)",
  weight: "الوزن (kg)",
  notes: "ملاحظات",
  saveVitals: "حفظ العلامات الحيوية",
  pastVitals: "السجلات الحيوية السابقة",
  noVitals: "لم يتم تسجيل أي علامات حيوية بعد.",
  recentHeartRate: "معدل ضربات القلب الأخير",

  fullName: "الاسم الكامل",
  age: "العمر",
  gender: "الجنس",
  height: "الطول (cm)",
  bloodType: "فصيلة الدم",
  allergies: "الحساسية",
  chronicConditions: "الأمراض المزمنة",
  currentMedications: "الأدوية الحالية",
  saveProfile: "حفظ الملف",

  free: "مجاني",
  pro: "احترافي",
  clinic: "عيادة",
  perMonth: "/شهر",

  loading: "جاري التحميل...",
  error: "حدث خطأ.",
  success: "تم بنجاح",
  retry: "إعادة المحاولة",
  cancel: "إلغاء",
  save: "حفظ",
  share: "شارك النتيجة",

  blogTitle: "المقالات الصحية",
  blogSubtitle: "رؤى يومية بالذكاء الاصطناعي",
  blogReadMore: "اقرأ المزيد",
  blogNoPosts: "لا توجد مقالات بعد. عد غدًا.",
  blogPublished: "نُشر",

  communityTitle: "أسئلة وأجوبة المجتمع",
  communitySubtitle: "اطرح أسئلتك وساعد الآخرين",
  newPost: "منشور جديد",
  postTitle: "العنوان",
  postBody: "السؤال أو الرسالة",
  yourName: "اسمك (اختياري)",
  publish: "نشر",
  replies: "الردود",
  reply: "رد",
  writeReply: "اكتب ردًا...",
  noPosts: "لا توجد نقاشات بعد. ابدأ أول واحد.",
  back: "رجوع",

  accountTitle: "حسابي",
  currentPlan: "الخطة الحالية",
  usageStats: "إحصائيات الاستخدام",
  upgrade: "ترقية الخطة",
  totalConsultations: "إجمالي الاستشارات",
  totalSymptomChecks: "إجمالي فحوصات الأعراض",
  totalDrugChecks: "إجمالي فحوصات الأدوية",
  totalVitalRecords: "إجمالي السجلات الحيوية",
  memberSince: "عضو منذ",

  cookieMessage:
    "نستخدم ملفات تعريف الارتباط لتحسين تجربتك وتحليل استخدام الموقع. باستمرارك توافق على سياسة الكوكيز.",
  accept: "موافق",
  decline: "رفض",

  privacyTitle: "سياسة الخصوصية",
  termsTitle: "شروط الخدمة",
  lastUpdated: "آخر تحديث",

  offlineMessage: "أنت غير متصل، سيتم استئناف العمل فور عودة الإنترنت.",

  tryAgain: "أعد المحاولة",
  posted: "نُشر",
};

const fr: Dict = {
  ...en,
  dashboard: "Tableau de bord",
  symptomChecker: "Analyseur de symptômes",
  drugInteractions: "Interactions médicamenteuses",
  consultations: "Consultations IA",
  vitalSigns: "Signes vitaux",
  healthProfile: "Profil de santé",
  pricing: "Tarifs",
  blog: "Blog santé",
  community: "Communauté",
  account: "Mon compte",
  privacy: "Politique de confidentialité",
  terms: "Conditions d'utilisation",
  brandSubtitle: "Intelligence santé",
  credit: "Conçu par l'Ing. Abdulrazzaq",
  quickActions: "Actions rapides",
  recentActivity: "Activité récente",
  healthTip: "Conseil santé du jour",
  loading: "Chargement...",
  share: "Partager ce résultat",
  cookieMessage:
    "Nous utilisons des cookies pour améliorer votre expérience. En continuant, vous acceptez notre politique.",
  accept: "Accepter",
  decline: "Refuser",
  offlineMessage: "Vous êtes hors ligne. Le travail reprendra à la reconnexion.",
};

const es: Dict = {
  ...en,
  dashboard: "Panel",
  symptomChecker: "Verificador de síntomas",
  drugInteractions: "Interacciones de medicamentos",
  consultations: "Consultas IA",
  vitalSigns: "Signos vitales",
  healthProfile: "Perfil de salud",
  pricing: "Precios",
  blog: "Blog de salud",
  community: "Comunidad",
  account: "Mi cuenta",
  privacy: "Política de privacidad",
  terms: "Términos del servicio",
  brandSubtitle: "Inteligencia de salud",
  credit: "Diseñado por Ing. Abdulrazzaq",
  quickActions: "Acciones rápidas",
  recentActivity: "Actividad reciente",
  healthTip: "Consejo de salud del día",
  loading: "Cargando...",
  share: "Compartir resultado",
  cookieMessage:
    "Usamos cookies para mejorar tu experiencia. Al continuar, aceptas nuestra política.",
  accept: "Aceptar",
  decline: "Rechazar",
  offlineMessage: "Estás desconectado. El trabajo se reanudará al reconectar.",
};

const zh: Dict = {
  ...en,
  dashboard: "仪表板",
  symptomChecker: "症状检查",
  drugInteractions: "药物相互作用",
  consultations: "AI 咨询",
  vitalSigns: "生命体征",
  healthProfile: "健康档案",
  pricing: "定价",
  blog: "健康博客",
  community: "社区",
  account: "我的账户",
  privacy: "隐私政策",
  terms: "服务条款",
  brandSubtitle: "健康智能",
  credit: "由 Eng. Abdulrazzaq 工程师设计",
  quickActions: "快捷操作",
  recentActivity: "最近活动",
  healthTip: "每日健康提示",
  loading: "加载中...",
  share: "分享此结果",
  cookieMessage: "我们使用 Cookie 改善您的体验。继续即表示您同意我们的政策。",
  accept: "接受",
  decline: "拒绝",
  offlineMessage: "您已离线，恢复连接后将继续工作。",
};

const hi: Dict = {
  ...en,
  dashboard: "डैशबोर्ड",
  symptomChecker: "लक्षण जाँच",
  drugInteractions: "दवा परस्पर क्रिया",
  consultations: "एआई परामर्श",
  vitalSigns: "महत्वपूर्ण संकेत",
  healthProfile: "स्वास्थ्य प्रोफ़ाइल",
  pricing: "मूल्य निर्धारण",
  blog: "स्वास्थ्य ब्लॉग",
  community: "समुदाय",
  account: "मेरा खाता",
  privacy: "गोपनीयता नीति",
  terms: "सेवा की शर्तें",
  brandSubtitle: "स्वास्थ्य बुद्धिमत्ता",
  credit: "इं. अब्दुलरज़्ज़ाक द्वारा डिज़ाइन",
  quickActions: "त्वरित क्रियाएँ",
  recentActivity: "हाल की गतिविधि",
  healthTip: "आज का स्वास्थ्य सुझाव",
  loading: "लोड हो रहा है...",
  share: "यह परिणाम साझा करें",
  cookieMessage: "हम आपके अनुभव को बेहतर बनाने के लिए कुकीज़ का उपयोग करते हैं।",
  accept: "स्वीकार करें",
  decline: "अस्वीकार करें",
  offlineMessage: "आप ऑफ़लाइन हैं। कनेक्ट होते ही कार्य फिर से शुरू होगा।",
};

const translations: Record<Language, Dict> = { en, ar, fr, es, zh, hi };

type I18nContextType = {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: keyof Dict) => string;
  dir: "ltr" | "rtl";
};

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem("language") as Language;
    return LANGUAGES.find((l) => l.code === saved)?.code ?? "en";
  });

  const dir = LANGUAGES.find((l) => l.code === language)?.dir ?? "ltr";

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem("language", lang);
  };

  useEffect(() => {
    document.documentElement.dir = dir;
    document.documentElement.lang = language;
    // Update hreflang alternates
    LANGUAGES.forEach((l) => {
      const id = `hreflang-${l.code}`;
      let link = document.getElementById(id) as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement("link");
        link.id = id;
        link.rel = "alternate";
        document.head.appendChild(link);
      }
      link.hreflang = l.code;
      link.href = `${window.location.origin}${window.location.pathname}?lang=${l.code}`;
    });
  }, [language, dir]);

  const t = (key: keyof Dict): string => {
    return translations[language][key] || translations.en[key] || (key as string);
  };

  return (
    <I18nContext.Provider value={{ language, setLanguage, t, dir }}>{children}</I18nContext.Provider>
  );
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (context === undefined) {
    throw new Error("useI18n must be used within an I18nProvider");
  }
  return context;
}
