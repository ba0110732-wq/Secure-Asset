# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## MediAI App

Bilingual+ AI health dashboard at `artifacts/medai` with backend at `artifacts/api-server`.

### Features
- 6 languages with hreflang/RTL: English, Arabic, French, Spanish, Chinese, Hindi (`src/lib/i18n.tsx`)
- Symptom Checker, Drug Interactions, AI Consultations, Vital Signs, Health Profile (AI via `chatJson`/`chatText`, OpenAI model `gpt-5.4` in dev)
- Health Blog: AI-generated daily articles in en+ar via `setInterval` cron (`routes/blog.ts`), `/blog` and `/blog/:slug` pages with markdown rendering
- Community Q&A: `/community`, `/community/:slug` with replies
- Account page (`/account`), Privacy (`/privacy`), Terms (`/terms`)
- PWA: `manifest.webmanifest` + `sw.js` + 192/512 icons in `public/`
- SEO: `/api/sitemap.xml` with hreflang alternates
- Cookie consent banner, social share buttons (WhatsApp/FB/Twitter/LinkedIn), offline indicator

### DB Tables
`users`, `health_profiles`, `vitals`, `symptom_checks`, `drug_checks`, `consultations`, `consultation_messages`, `blog_posts`, `community_posts`, `community_replies`. Push: `pnpm --filter @workspace/db run push-force`.

### Deployment (free)
- `render.yaml` — deploys API server to Render free tier
- `vercel.json` — deploys frontend to Vercel free tier (replace `YOUR-RENDER-API` with real URL)
- `DEPLOY.md` — step-by-step guide using Neon/Supabase + Render + Vercel

### Codegen note
`lib/api-spec/package.json` runs a post-orval node step that overwrites `lib/api-zod/src/index.ts` to only export from `./generated/api` (avoids zod-schema vs TS-type name collision).
